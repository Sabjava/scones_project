import json
import sagemaker
import base64
import boto3
from sagemaker.serializers import IdentitySerializer
from sagemaker.predictor import Predictor


ENDPOINT = 'image-classification-2024-09-26-21-52-25-323'

def lambda_handler(event, context):
    """A function to run inference on an image using SageMaker"""

    image = base64.b64decode(event['body']['image_data'])

    predictor = Predictor(endpoint_name=ENDPOINT)   
    predictor.serializer = IdentitySerializer("image/png")
    inferences = predictor.predict(image)
    event["inferences"] = inferences.decode('utf-8') 
    return {
        'statusCode': 200,
        'body': json.dumps(event)
    }
