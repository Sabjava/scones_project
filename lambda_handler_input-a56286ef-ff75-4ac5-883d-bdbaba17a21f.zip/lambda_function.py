import json

import base64
import os
import boto3

s3 = boto3.client('s3')

def lambda_handler(event, context):
    """A function to serialize target data from S3"""
    
    # Get the S3 bucket and key from the Step Function event input
    key = event['s3_key']  # Assuming the event has 's3_key'
    bucket = event['s3_bucket']  # Assuming the event has 's3_bucket'
    
    # Download the data from s3 to /tmp/image.png
    download_path = '/tmp/image.png'
    s3.download_file(bucket, key, download_path)
    
    # We read the data from the file and encode it
    with open(download_path, "rb") as f:
        image_data = base64.b64encode(f.read()).decode('utf-8')  # Convert bytes to string
    
    # Log the event details (for debugging purposes)
    print("Event:", event)
    
    # Return the response to the Step Function
    return {
        'statusCode': 200,
        'body': json.dumps({
            "image_data": image_data,
            "s3_bucket": bucket,
            "s3_key": key,
            "inferences": []  # Empty, to be filled by further steps in Step Function
        })
    }
